require 'rails_helper'

RSpec.describe ChargesController, type: :controller do

end
