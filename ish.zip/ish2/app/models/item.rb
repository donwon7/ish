class Item < ActiveRecord::Base
  belongs_to :user
  belongs_to :location
  has_attached_file :ipic
  validates_attachment_content_type :ipic, :content_type => ["image/jpg", "image/jpeg", "image/png", "image/gif"]
end
