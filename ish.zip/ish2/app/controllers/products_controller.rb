class ProductsController < ApplicationController

    def index
    end

    def create
        @user = User.find(session[:user_id])
    end

    def new
        user = User.find_by(id: session[:user_id])
        if Location.find_by(city: params[:city])
            location = Location.find_by(city: params[:city])
        else
            location = Location.create(city: params[:city], state: params[:state])
        end
        item = Item.create(name: params[:name], price: params[:price], description: params[:description], user: user, location: location)
        redirect_to '/users'
    end
end